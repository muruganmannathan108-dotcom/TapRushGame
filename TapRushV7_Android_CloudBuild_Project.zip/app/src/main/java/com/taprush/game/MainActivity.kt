package com.taprush.game

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.LoadAdError

class MainActivity : Activity() {
    private var rewardedAd: RewardedAd? = null
    private lateinit var web: WebView
    // Google-provided Android rewarded test ad unit. Replace with your own before publishing.
    private val rewardedUnitId = "ca-app-pub-3940256099942544/5224354917"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AdBridge(), "AndroidAds")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        loadRewarded()
    }

    private fun loadRewarded() {
        RewardedAd.load(this, rewardedUnitId, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewardedAd = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { rewardedAd = null }
            })
    }

    inner class AdBridge {
        @JavascriptInterface fun showRewarded() {
            runOnUiThread {
                val ad = rewardedAd
                if (ad == null) {
                    Toast.makeText(this@MainActivity, "Reward ad is loading. Try again shortly.", Toast.LENGTH_SHORT).show()
                    loadRewarded()
                    return@runOnUiThread
                }
                ad.show(this@MainActivity) { _: RewardItem ->
                    web.evaluateJavascript("window.rewardFromAd && window.rewardFromAd()", null)
                }
                rewardedAd = null
                loadRewarded()
            }
        }
    }
}