package com.taprush.game
import android.app.Application
import com.google.android.gms.ads.MobileAds
class TapRushApplication: Application() {
 override fun onCreate() { super.onCreate(); MobileAds.initialize(this) }
}