plugins { id("com.android.application") }
android { namespace="com.taprush.game"; compileSdk=36
 defaultConfig { applicationId="com.taprush.game"; minSdk=23; targetSdk=36; versionCode=2; versionName="1.1" }
}
dependencies {
 implementation("com.google.android.gms:play-services-ads:24.6.0")
}
