# Tap Rush V7 — Android + AdMob + Phone Cloud Build

Tap Rush V7 continues V6 and adds a phone-friendly cloud build workflow.

## What V7 adds
- Android Gradle Plugin 8.11.1, documented for API 36 support.
- Gradle 8.13 in the cloud build workflow.
- GitHub Actions workflow that builds a debug APK.
- Android SDK 36 installation in the workflow.
- APK is uploaded as a downloadable GitHub Actions artifact.
- Existing V6 rewarded-ad test integration is retained.

## Important AdMob note
The project still uses Google's test AdMob app/ad-unit IDs. Keep these for development/testing only. Before publishing, replace them with your own AdMob IDs and complete the required privacy/consent and Play Console declarations.

## Build from an Android phone
1. Create/sign in to a GitHub account.
2. Create a new repository, for example `tap-rush`.
3. Upload the contents of this project ZIP to the repository (not the ZIP file itself).
4. Open the repository's **Actions** tab.
5. Select **Build Tap Rush APK** and run the workflow, or push to `main`.
6. When it finishes, open the workflow run and download the `tap-rush-v7-debug-apk` artifact.
7. Extract the APK on your phone and install it for testing.

This workflow creates a debug APK for testing. It is NOT a Play Store release build and is not signed with a production upload key.

## Play Store preparation still needed
- Production signing/upload key.
- Release AAB build.
- Production AdMob IDs.
- Privacy policy and required consent flow.
- Google Play Data safety and ads declarations as applicable.
- App icon, screenshots, description, category, content rating and store listing.
- Final testing on real devices.
